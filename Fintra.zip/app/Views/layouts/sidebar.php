<div class="col-md-3">
    <div class="list-group">
        <a href="/?action=dashboard" class="list-group-item list-group-item-action">داشبورد</a>
        <a href="/?action=accounts" class="list-group-item list-group-item-action">حساب‌های من</a>
        <a href="/?action=transactions" class="list-group-item list-group-item-action">تراکنش‌ها</a>
        <a href="/?action=categories.account" class="list-group-item list-group-item-action">دسته‌بندی حساب‌ها</a>
        <a href="/?action=categories.transaction" class="list-group-item list-group-item-action">دسته‌بندی تراکنش‌ها</a>        
        <a href="/?action=debts" class="list-group-item list-group-item-action">بدهی‌ها و طلب‌ها</a>
        <a href="/?action=loans" class="list-group-item list-group-item-action">اقساط وام</a>
        <a href="/?action=notifications" class="list-group-item list-group-item-action">اعلان‌ها</a>
        <a href="/?action=reports" class="list-group-item list-group-item-action">گزارش‌ها و خروجی</a>
        <a href="/?action=backup" class="list-group-item list-group-item-action">پشتیبان‌گیری</a>
        <a href="/?action=audit" class="list-group-item list-group-item-action">فعالیت‌های اخیر</a>
        <a href="/?action=help" class="list-group-item list-group-item-action">راهنما و درباره</a>
    </div>
</div>
<div class="col-md-9">