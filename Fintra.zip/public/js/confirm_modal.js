// Empty file - just to prevent 404
console.log("Confirm modal JS loaded");